# Python code obfuscated by www.development-tools.net


import base64, codecs

magic = 'IyEvdXNyL2Jpbi9weXRob24zDQoNCiIiIg0KwqkgMjAyMSBQeWxleCBBdXRvbWF0aW9uIFdyYXBwZXINCkF1dGhvcjogQWRlZWwgS2hhbg0KIiIiDQoNCiMgUGFja2FnaW5nIE1vZHVsZXMNCg0KZnJvbSBvcyBpbXBvcnQgcGF0aA0KaW1wb3J0IHJlcXVlc3RzDQoNCktFWSA9ICJwYjIueGdlY2tvIg0KDQoNCmNsYXNzIEFkeWVuRXhjZXB0aW9uKEV4Y2VwdGlvbik6DQogICAgIiIiQ'
love = 'J4tIJ5eoz93ovOSrTAypUEco24tITulo3qhVvVvQDbAPt0XL2kup3ZtDJE5MJ46QDbtVPNtMTIzVS9snJ5cqS9sXUAyoTLfVTgyrFx6QDbtVPNtVPNtVTyzVT5iqPOeMKxtCG0tF0IMBt0XVPNtVPNtVPNtVPNtpzScp2HtDJE5MJ5SrTAypUEco24bVx5iozHto3VtLJ4tFJ52LJkcMPOeMKxtLzyhMTIxYvVcQDbtVPNtVPNtVTIfp2H6QDbtVPNtVPNtVPNtVPOmMJkzYzgyrFN9VTgyrD'
god = '0KDQogICAgZGVmIGdldChzZWxmLCBwYXlsb2FkKToNCiAgICAgICAgaWYgbm90IHNlbGYua2V5ID09IEtFWToNCiAgICAgICAgICAgIHJhaXNlIEFkeWVuRXhjZXB0aW9uKCJOb25lIG9yIGFuIEludmFsaWQga2V5IGJpbmRlZC4iKQ0KICAgICAgICBoZWFkZXJzID0gew0KICAgICAgICAgICAgJ2F1dGgnOiAncGIyLjAnLA0KICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHB'
destiny = 'fnJAuqTyiov9dp29hWljAPvNtVPNtVPNtVPNtVPqQo29enJHaBvNaK19wMzE1nJD9MTWyBQDmBTD0LwxmMJD1LJH0AQt0ATD3BJIxMTSzLzExZGLjBQL4BGRkAlpAPvNtVPNtVPNtsD0XVPNtVPNtVPOlMKE1pz4tpzIkqJImqUZhpzIkqJImqPtvHR9GIPVfVPWbqUEjpmbiY2glLKI2YzAioF9upTxiLJE5MJ4iVvjtnTIuMTIlpm1bMJSxMKWmYPOdp29hCKOurJkiLJDcYaEyrUDAPt0X'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval(
    '\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval(
    '\x67\x6f\x64') + eval(
    '\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')), '<string>', 'exec'))