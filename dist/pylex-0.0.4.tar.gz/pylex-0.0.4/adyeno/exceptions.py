#!/usr/bin/python3
# pylex Exceptions


class Default(Exception):
    """An Unknown Exception Thrown"""
